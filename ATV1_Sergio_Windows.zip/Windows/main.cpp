#include "windows.h"
#include "main.h"

//-----------------------------------------------------------------------------
void MyGlDraw(void)
{
	//Variáveis auxiliares
    int cor0[4] = {255, 0, 0, 255};
    int cor1[4] = {0, 255, 0, 255};
    int cor2[4] = {0, 0, 255, 255};

    //PutPixel(256,256,cor0);

	//Desenha Pontos
    /*PutPixel(256,106,cor0);
    PutPixel(356,206,cor1);
    PutPixel(156,306,cor2);*/

    //Desenha Linhas
    /*DrawLine(480,200,30,500,cor0,cor1);
    DrawLine(306, 206, 256, 106,cor2,cor0);*/

    //Desenha Triângulo
    DrawTriangle(106, 406, 256, 106, 406, 406, cor0, cor1, cor2);
}

//-----------------------------------------------------------------------------
int main(int argc, char **argv)
{
	// Inicializações.
	InitOpenGL(&argc, argv);
	InitCallBacks();
	InitDataStructures();

	// Ajusta a função que chama as funções do mygl.h
	DrawFunc = MyGlDraw;

	// Framebuffer scan loop.
	glutMainLoop();

	return 0;
}

